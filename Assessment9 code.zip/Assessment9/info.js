document.getElementById("form").onsubmit=login
var uname=document.getElementById("name");
var email = document.getElementById("email");
var rate=document.getElementById("rating");
var location=document.getElementById("location");
var time=document.getElementById("time");
var emotion=document.getElementById("emotion");
var area=document.getElementById("area");
var btn = document.getElementById("btn");

uname.focus();

function login()
{
    name=uname.value;
    if(name=="")
    {
        var value1="*username cannot be empty";
        document.getElementById("uerror").innerHTML=value1;
        passdom.style.borderColor="#f73434";
    }
    email=email.value;
    var symbols =  /@.com/.test(email); 
    if(symbols)
    {
            window.location.href="https://www.google.com/";
       
    }
    else
    {
        var value="*Must contain @symbol";
        document.getElementById("error").innerHTML=value;
        passdom.style.borderColor="#f73434";
    }
}